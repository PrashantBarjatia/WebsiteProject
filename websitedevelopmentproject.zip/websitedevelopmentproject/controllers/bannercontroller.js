const bannerTable=require('../models/banner')
const fs=require('fs')

exports.bannermangement=async(req,res)=>{
    let message=''
    try{
    var username=req.session.loginname
    var data=await bannerTable.find()
    var trecord=await bannerTable.find().count()
    var precord=await bannerTable.find({status:'Published'}).count()
    var urecord=await bannerTable.find({status:'Unpublished'}).count()

    if(data.length==0){
        throw new Error("No Record Found")
    }
    }catch(error){
        message=error.message
    }
    res.render('admin/bannermangement.ejs',{username,data,message,trecord,precord,urecord})
}

    

exports.bannerform=(req,res)=>{
    let message=''
    const username=req.session.loginname
    res.render('admin/bannerform.ejs',{username,message})
}

exports.newbanner=(req,res)=>{
    const username=req.session.loginname
    let message=''
    try{
    const{title,desc,mdesc}=req.body
    if(!title || !desc || !mdesc) {
        throw new Error("All fields are compulsory fileds , Please fill!!")
    }else if(desc.length >300){
        throw new Error("Description length shoud not be greater than 300!!")
    }else if (smdesc.length >600) {
        throw new Error("More Description length shoud not be greater than 600!!")
    }else if(!req.file){
        throw new Error("Banner Image is required!!!. Please upload Image")
    }
    const filename=req.file.filename
    const newbanner=new bannerTable({title:title,desc:desc,moredesc:mdesc,img:filename})
    newbanner.save()
    message='Successfully banner has been added!!'
    
    }catch(error){
        message=error.message
    }
    res.render('admin/bannerform.ejs',{username,message})
}

exports.statusupdate=async(req,res)=>{
    let currentStatus=req.params.status
    let id=req.params.id
    let updateStatus=null
    if(currentStatus=='Unpublished'){
        updateStatus='Published'
    }else{
        updateStatus='Unpublished'
    }
   
    await bannerTable.findByIdAndUpdate(id,{status:updateStatus})
    res.redirect('/admin/bannermangement')

}

exports.delete=async(req,res)=>{
    const id=req.params.id
    const img=req.params.imgname
    await bannerTable.findByIdAndDelete(id)
    fs.unlinkSync(`./public/upload/${img}`)
    res.redirect('/admin/bannermangement')
}

exports.moredetails=async(req,res)=>{
    const data=await bannerTable.findOne({status:'Published'})
    res.render('banner.ejs',{data})
}

exports.bannerupdateform=async(req,res)=>{
    const username=req.session.loginname
    const id=req.params.id
    const data=await bannerTable.findById(id)
    res.render('admin/bannerupdateform.ejs',{username,data})
}
exports.bannerupdate=async(req,res)=>{
    const img=req.params.img
    const id=req.params.id
    const {title,desc,moredesc}=req.body
    if(req.file){
    const filename=req.file.filename
    await bannerTable.findByIdAndUpdate(id,{title:title,desc:desc,moredesc:moredesc,img:filename})
    fs.unlinkSync(`./public/upload/${img}`)
    }else{
        await bannerTable.findByIdAndUpdate(id,{title:title,desc:desc,moredesc:moredesc})
    }
    res.redirect('/admin/bannermangement')
}