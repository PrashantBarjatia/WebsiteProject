const regTable=require('../models/reg')

exports.loginform=(req,res)=>{
    res.render('admin/adminlogin.ejs',{message:''})
}
exports.logincheck=async(req,res)=>{
    try{
    const {us,pass}=req.body
    if(!us){
        throw new Error("username is should not blank!!")
    }
    if(!pass){
        throw new Error("password is should not be blank!!")
    }
    const data=await regTable.findOne({username:us})
    if(data!==null){
        if(data.password==pass){
            req.session.isAuth=true
            req.session.loginname=us
            res.redirect('/admin/dashboard')
        }else{
       res.render('admin/adminlogin.ejs',{message:'Wrong Password'})
        }
    }else{
        res.render('admin/adminlogin.ejs',{message:'WrongUsername'})
    }
    }catch(error){
        res.render('admin/adminlogin.ejs',{message:error.message})
    }
} 

exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/admin/')}