const { Error } = require('mongoose')
const serviceTable = require('../models/service')
const fs=require('fs')
const { name } = require('ejs')

exports.servicemanagement = async(req, res) => {
    let message=''
    try{
    var username = req.session.loginname
    var data=await serviceTable.find()
    var trecord=await serviceTable.find().count()
    var precord=await serviceTable.find({status:'Published'}).count()
    var urecord=await serviceTable.find({status:'Unpublished'}).count()

    if(data.length==0){
        throw new Error("No Record found!!")
    }
    }catch(error){
        message=error.message   
    }
    res.render('admin/servicemanagement.ejs', { username,data,message,trecord,precord,urecord })

}

exports.serviceform = (req, res) => {
    let message=''
    const username = req.session.loginname
    res.render('admin/serviceform.ejs', { username,message })
}

exports.newservice = (req, res) => {
    let message=''
    const { sname, sdesc, smdesc } = req.body
    
    try {
        if (!sname || !sdesc || !smdesc) {
            throw new Error("All fields are compulsory fileds , Please fill!!")
        } else if (sdesc.length >300) {
            throw new Error("Description length shoud not be greater than 300!!")
        } else if (smdesc.length >600) {
            throw new Error("More Description length shoud not be greater than 600!!")
        } else if (!req.file){
            throw new Error("Service Img is compulsory.Please Add!!")
        }
        const newservice = new serviceTable({ name: sname, desc: sdesc, mdesc: smdesc, img:req.file.filename })
        newservice.save()
        message='Successfully Service has been Added!!'
    } catch (error) {
        message=error.message
    }
    const username = req.session.loginname
    res.render('admin/serviceform.ejs',{username,message})
}  

exports.servicestatusupdate=async(req,res)=>{
    const status=req.params.status
    const id=req.params.id
    let newstatus=null
    if(status=='Unpublished'){
        newstatus='Published'
    }else{
        newstatus='Unpublished'
    }
    await serviceTable.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/servicemanagement')
}

exports.delete=async(req,res)=>{
    const id=req.params.id
    const img=req.params.imgname
    await serviceTable.findByIdAndDelete(id)
    fs.unlinkSync(`./public/upload/${img}`)
    res.redirect('/admin/servicemanagement')
}

exports.servicesupdateform=async(req,res)=>{
    const username = req.session.loginname
    const id=req.params.id
    const data=await serviceTable.findById(id)
    res.render('admin/servicesupdateform.ejs',{username,data})
}

exports.servicesupdate=async(req,res)=>{
    const img=req.params.img
    const id=req.params.id
    const {name,desc,mdesc}=req.body
    if(req.file){
        const filename=req.file.filename
        await serviceTable.findByIdAndUpdate(id,{name:name,desc:desc,mdesc:mdesc,img:filename})
        fs.unlinkSync(`./public/upload/${img}`)
    }else{
        await serviceTable.findByIdAndUpdate(id,{name:name,desc:desc,mdesc:mdesc})
    }
    res.redirect('/admin/servicemanagement')

}

exports.servicesmoredetails=async(req,res)=>{
    const id=req.params.id
    const data=await serviceTable.findById(id)
    res.render('servicemoredetails.ejs',{data})
}