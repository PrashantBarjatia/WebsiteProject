const testiTable=require('../models/testi')
const fs=require('fs')

exports.testimanagement=async(req,res)=>{
    let message=''
    try{
    var username=req.session.loginname
    var data=await testiTable.find()
    var trecord=await testiTable.find().count()
    var precord=await testiTable.find({status:'Published'}).count()
    var urecord=await testiTable.find({status:'Unpublished'}).count()

    if(data.length==0){
        throw new Error("No Record Found")
    }
    }catch(error){
        message=error.message
    }
    res.render('admin/testimanagement.ejs',{username,data,message,trecord,precord,urecord})

}


exports.testiform=(req,res)=>{
    let message=''
    res.render('./testiform.ejs',{message})
}

exports.newtesti=(req,res)=>{
    let message=''
    const {name,desc}=req.body
    try{
        if(!name || !desc){
            throw new Error("All fields are compulsory fileds , Please fill!!")
        }else if(desc.length >300){
            throw new Error("Description length shoud not be greater than 300!!")
        }else if(!req.file){
            throw new Error("Testinominal Image is compulsary Please add!!")
        }
        const newtesti= new testiTable({name:name,desc:desc,img:req.file.filename})
        newtesti.save()
        message='Successfully Service has been Added!!'
    }catch (error){
        message=error.message
    }
    res.render('./testiform.ejs',{message})
    
}

exports.testistatusupdate=async(req,res)=>{
    const status=req.params.status
    const id=req.params.id

    if(status=='Unpublished'){
        newstatus='Published'
    }else{
        newstatus='Unpublished'
    }
    await testiTable.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/testimanagement')
}

exports.delete=async(req,res)=>{
    const id=req.params.id
    const img=req.params.imgname
    await testiTable.findByIdAndDelete(id)
    fs.unlinkSync(`./public/upload/${img}`)
    res.redirect('/admin/testimanagement')
}

exports.testiupdateform=async(req,res)=>{
    const username=req.session.loginname
    const id=req.params.id
    const data=await testiTable.findById(id)
    res.render('admin/testiupdateform.ejs',{username,data}) 
}

exports.testiupdate=async(req,res)=>{
    const img=req.params.img
    const {name,desc}=req.body
    const id=req.params.id
    if(req.file){
    const filename=req.file.filename
    const data=await testiTable.findByIdAndUpdate(id,{name:name,desc:desc,img:filename})
    fs.unlinkSync(`./public/upload/${img}`)
    }else{
    const data=await testiTable.findByIdAndUpdate(id,{name:name,desc:desc})
    }
    res.redirect('/admin/testimanagement')

}