const mongoose=require('mongoose')

const serviceSchema=mongoose.Schema({
    img:{
        type:String,
        required:true
    },
    name:{
        type:String,
        required:true
    },
    desc:{
        type:String,
        required:true
    },
    mdesc:{
        type:String,
        required:true
    },
    createDate:{
        required:true,
        type:Date,
        default:new Date()
    },
    status:{
        type:String,
        default:'Unpublished',
        required:true
    }
})

module.exports=mongoose.model('service',serviceSchema)