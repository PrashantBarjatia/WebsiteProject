const mongoose=require('mongoose')

const testiSchema=mongoose.Schema({
    img:{
        type:String,
        required:true
    },
    name:{
        type:String,
        required:true
    },
    desc:{
        type:String,
        required:true
    },
    createDate:{
        required:true,
        type:Date,
        default:new Date ()
    },
    status:{
        type:String,
        default:'Unpublished',
        required:true
    }
})

module.exports=mongoose.model('testi',testiSchema)