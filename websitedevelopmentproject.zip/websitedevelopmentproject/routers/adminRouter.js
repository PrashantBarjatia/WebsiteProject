const router = require('express').Router()
const regc = require('../controllers/regcontroller')
const bannerc = require('../controllers/bannercontroller')
const servicec = require('../controllers/servicecontroller')
const testic = require('../controllers/testicontroller')
const queryc = require('../controllers/querycontroller')
const upload = require('../midleware/multer')
const nodemailer = require('nodemailer')


const handlelogin = require('../midleware/sessioncheck')
const testi = require('../models/testi')


router.get('/', regc.loginform).post('/', regc.logincheck)
router.get('/dashboard', handlelogin, (req, res) => {
    const username = req.session.loginname
    res.render('admin/dashboard.ejs', { username })
})
router.get('/logout', regc.logout)

router.get('/bannermangement', handlelogin, bannerc.bannermangement)
router.get('/newbanner', handlelogin, bannerc.bannerform).post('/newbanner', upload.single('img'), bannerc.newbanner)
router.get('/bannersupdate/:status/:id', bannerc.statusupdate)
router.get('/bannerdelete/:id/:imgname', bannerc.delete)
router.get('/bannerupdate/:id/:img', bannerc.bannerupdateform).post('/bannerupdate/:id/:img', upload.single('img'), bannerc.bannerupdate)
//banner router end!!

router.get('/servicemanagement', handlelogin, servicec.servicemanagement)
router.get('/serviceadd', servicec.serviceform).post('/serviceadd', upload.single('img'), servicec.newservice)
router.get('/serviceschange/:status/:id', servicec.servicestatusupdate)
router.get('/servicesdelete/:id/:imgname', servicec.delete)
router.get('/servicesupdate/:id/:img', servicec.servicesupdateform).post('/servicesupdate/:id/:img', upload.single('img'), servicec.servicesupdate)
//service router end!!

router.get('/testimanagement', handlelogin, testic.testimanagement)
router.get('/testichange/:status/:id', testic.testistatusupdate)
router.get('/testidelete/:id/:imgname', testic.delete)
router.get('/testiupdate/:id/:img', testic.testiupdateform).post('/testiupdate/:id/:img', upload.single('img'), testic.testiupdate)
//testi router end!!

router.get('/query/:mess',handlelogin, queryc.bannerdata)
router.get('/querydelete/:id', queryc.delete)
router.get('/queryform/:email/:query/:id',queryc.queryform).post('/queryform/:email/:query/:id',queryc.sendemail)
//query router end!!



module.exports = router