const router=require('express').Router()
const bannerTable=require('../models/banner')
const serviceTable=require('../models/service')
const testiTable=require('../models/testi')

router.get('/',async(req,res)=>{
    const data=await bannerTable.findOne({status:'Published'})
    const servicedata=await serviceTable.find({status:'Published'})
    const testidata=await testiTable.find({status:'Published'})
    res.render('index.ejs',{data,servicedata,testidata})
})

module.exports=router