const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const queryc=require('../controllers/querycontroller')
const upload=require('../midleware/multer')

router.get('/mbanner',bannerc.moredetails)
router.get('/servicesmoredetails/:id',servicec.servicesmoredetails)

router.get('/testireviwadd',testic.testiform)
router.post('/testireviwadd',upload.single('img'),testic.newtesti)

router.post('/',queryc.addquery)

module.exports=router